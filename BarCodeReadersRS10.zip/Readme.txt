Original download
http://cc.embarcadero.com/item/29699 
https://github.com/null09264/ZBarSDK-for-iOS
